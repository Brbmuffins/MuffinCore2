#ifndef MOD_BOT_AI_LOADER_H
#define MOD_BOT_AI_LOADER_H

// Forward declaration
void AddBotAIScripts();

#endif
